# Images folder for VMS

This folder will store the images uploaded using newvisitor.php.  
File names are randomly generated UUIDs tracked in the database.
